Original ChooChooTracker SQ80/ESQ starter presets, created for Rev2.
These parameter programs are provided under the repository license.
No downloaded preset bytes or waveform samples are used. External wave banks are required.
